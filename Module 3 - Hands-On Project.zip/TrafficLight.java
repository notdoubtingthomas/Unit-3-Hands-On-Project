import java.sql.SQLOutput;
import java.util.Scanner;

/*
Unit 3 Project 2: TrafficLight (Starter with TODOs)
Create a TrafficLight class with color and duration, plus methods to change color and check red/green.
*/

public class TrafficLight {
    // TODO 1: attributes: color (String), duration (int seconds)
    private String color;
    private int duration;

    // TODO 2: constructor TrafficLight(String color, int duration)
    public TrafficLight(String color, int duration) {
        this.color = color;
        this.duration = duration;
    }
    // TODO 3: changeColor(String newColor)
    public void changeColor(String newColor) {
        this.color = newColor;
    }
    // TODO 4: isRed() -> boolean
    public boolean isRed() {
        return color.equalsIgnoreCase("RED");
    }
    // TODO 5: isGreen() -> boolean
    public boolean isGreen() {
        return color.equalsIgnoreCase("GREEN");
    }
    // TODO 6: toString()
    public String toString() {
        return "Traffic Light [color = " + color + ", duration = " + duration + " seconds]";
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // TODO 7: Create TrafficLight("RED", 30) and print state
        TrafficLight trafficLight = new TrafficLight("RED", 30);
        System.out.println(trafficLight);
        System.out.println("Is red? " + trafficLight.isRed());
        System.out.println("Is green? " + trafficLight.isGreen());

        // TODO 8: Prompt user to enter new colors at least twice and print checks after each change

        System.out.println("Enter two new colors. ");
        System.out.print("Enter color one: ");
        String color1 = input.nextLine();

        trafficLight.changeColor(color1);

        System.out.print("Enter color two: ");
        String color2 = input.nextLine();

        trafficLight.changeColor(color2);

        System.out.println(trafficLight);
        System.out.println("Is red? " + trafficLight.isRed());
        System.out.println("Is green? " + trafficLight.isGreen());

        input.close();
    }
}
