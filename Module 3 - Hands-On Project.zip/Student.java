import java.util.ArrayList;
import java.util.Scanner;

/*
Unit 3 Project 4: Student
Create a Student class with name, grade, course list; add/remove courses via menu.
*/

public class Student {

    // TODO 1: attributes
    private String name;
    private double grade;
    private ArrayList<String> courses;

    // TODO 2: constructor
    public Student(String name, double grade) {
        this.name = name;
        this.grade = grade;
        this.courses = new ArrayList<>();
    }

    // TODO 3: addCourse
    public void addCourse(String course) {
        courses.add(course);
    }

    // TODO 4: removeCourse
    public void removeCourse(String course) {
        courses.remove(course);
    }

    // TODO 5: listCourses
    public void listCourses() {
        if (courses.isEmpty()) {
            System.out.println("No courses enrolled.");
        } else {
            System.out.println("Courses:");
            for (String course : courses) {
                System.out.println("- " + course);
            }
        }
    }

    // TODO 6: toString
    public String toString() {
        return "Student [name=" + name + ", grade=" + grade + "]";
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // TODO 7: Prompt for name and grade
        System.out.print("Enter name: ");
        String name = input.nextLine();

        System.out.print("Enter grade: ");
        double grade = input.nextDouble();
        input.nextLine();

        Student student = new Student(name, grade);

        // TODO 8: Menu loop
        boolean running = true;

        while (running) {
            System.out.println("\nMenu:");
            System.out.println("1. Add course");
            System.out.println("2. Remove course");
            System.out.println("3. List courses");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");

            int choice = input.nextInt();
            input.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter course to add: ");
                    String addCourse = input.nextLine();
                    student.addCourse(addCourse);
                    break;

                case 2:
                    System.out.print("Enter course to remove: ");
                    String removeCourse = input.nextLine();
                    student.removeCourse(removeCourse);
                    break;

                case 3:
                    student.listCourses();
                    break;

                case 4:
                    running = false;
                    break;

                default:
                    System.out.println("Invalid choice.");
            }
        }

        System.out.println("\nFinal student info:");
        System.out.println(student);
        student.listCourses();

        input.close();
    }
}
